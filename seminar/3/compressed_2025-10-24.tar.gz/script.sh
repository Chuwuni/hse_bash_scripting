#!/bin/bash
tar -czvf compressed_$(date +"%Y-%m-%d").tar.gz $1